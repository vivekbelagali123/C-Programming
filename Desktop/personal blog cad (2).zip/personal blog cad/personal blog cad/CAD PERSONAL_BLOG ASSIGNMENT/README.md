# Cad_personal-blog

### Task: To create a Personal-blog website 

IDE: vs code <br>
Technology used html,css and javascript

<br>